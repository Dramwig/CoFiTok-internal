# CoFiTok Draft Figures and Tables

All figures below are source-backed by files under `../CoFiTok-internal/`.
Do not move large image directories into `paper/`; keep links to the existing
artifact paths until a venue-specific LaTeX project is selected.

## Main Figures

### Figure 1: Method Overview

Paths:

```text
../CoFiTok-internal/artifacts/figures/method_overview_2026-07-08/method_overview.png
../CoFiTok-internal/artifacts/figures/method_overview_2026-07-08/method_overview.svg
../CoFiTok-internal/artifacts/figures/method_overview_2026-07-08/method_overview_manifest.json
```

Caption draft:

> CoFiTok factorizes dense pixel-space diffusion noise prediction into ordered
> compressed denoising tokens. The predictor may be expressive, but each
> synthesis operator `S_k` receives only the current token and is restricted to
> shallow, condition-free, bias-free local synthesis. Any prefix of components
> forms a valid partial noise prediction and therefore a valid pixel-space
> denoising result. Dashed blocked paths mark information that must not enter
> `S_k`, including `x_t`, timesteps, labels, prompts, previous tokens, skip
> features, and learned constants.

### Figure 2: Prefix Denoising at 20k Steps

Path:

```text
../CoFiTok-internal/artifacts/figures/visual_panels_2026-07-08/prefix_comparison_20k.png
```

Caption draft:

> Prefix denoising grids for Tiny ImageNet-200 and ImageNet-64 HF at 20k
> training steps. Epsilon-only training reaches a comparable final endpoint but
> does not train meaningful intermediate prefixes. K8 light CoFiTok reveals
> denoising structure through later prefixes while preserving endpoint quality
> close to the epsilon-only baseline.

### Figure 3: Order Ablation

Paths:

```text
../CoFiTok-internal/artifacts/figures/summary_2026-07-08/imagenet_hf_order_path_auc.png
../CoFiTok-internal/artifacts/figures/visual_panels_2026-07-08/order_ablation_prefix_panel.png
```

Caption draft:

> Component order affects prefix quality even when the final component sum is
> unchanged. Ordered components preserve the denoise path, while random and
> reverse orders damage prefix alignment, especially for K8 and K16.

### Figure 4: Restricted Synthesis Diagnostics

Path:

```text
../CoFiTok-internal/artifacts/figures/visual_panels_2026-07-08/sk_diagnostic_panel.png
```

Caption draft:

> Restricted synthesis and deep-synthesis diagnostics on ImageNet-64 HF.
> Restricted `S_k` satisfies `S_k(0)=0` by construction and shuffled tokens do
> not match the original images. The deep `S_k` ablation improves apparent
> quality but fails the zero-token diagnostic, indicating degeneration risk.

### Figure 5: 20k Quantitative Tradeoff

Paths:

```text
../CoFiTok-internal/artifacts/figures/summary_2026-07-08/path_auc_20k.png
../CoFiTok-internal/artifacts/figures/summary_2026-07-08/final_clean_mse_20k.png
../CoFiTok-internal/artifacts/figures/summary_2026-07-08/effective_tokens_20k.png
```

Caption draft:

> At the same 20k budget, K8 light CoFiTok nearly matches epsilon-only final
> clean MSE while greatly reducing prefix path AUC and using more tokens
> effectively on Tiny ImageNet-200 and ImageNet-64 HF.

### Figure 6: Generated-Sample Smoke

Paths:

```text
../CoFiTok-internal/artifacts/figures/summary_2026-07-08/generated_inception_20k_1024.png
../CoFiTok-internal/artifacts/figures/summary_2026-07-08/generated_inception_20k_8192.png
../CoFiTok-internal/artifacts/figures/summary_2026-07-08/generated_inception_20k_hf_50000.png
../CoFiTok-internal/artifacts/figures/visual_panels_2026-07-08/sampling_comparison_20k.png
```

Caption draft:

> Generated-sample smoke-to-medium evaluation with DDIM sampling. The plotted
> 1024/4096 DDIM-20 figure favors epsilon-only, while the larger streamed
> 8192/8192 DDIM-50 figure and the HF 50000/50000 streamed protocol remain
> mixed or epsilon-favoring across datasets. Matched 20k multiscale generated
> quality controls improve absolute Frechet values but still favor epsilon-only.
> CoFiTok should not claim a robust unconditional generation-quality win at the
> current tiny-model scale.

## Main Tables

### Table 1: 20k Fair Comparison

| Dataset | Method | Final clean MSE | Path AUC | Effective K | Zero ratio |
|---|---:|---:|---:|---:|---:|
| Tiny ImageNet-200 | epsilon-only | 0.1413 | 1.1121 | 5.336 | 0.0000 |
| Tiny ImageNet-200 | K8 light | 0.1427 | 0.0388 | 6.780 | 0.0000 |
| ImageNet-64 HF | epsilon-only | 0.0842 | 1.0746 | 5.240 | 0.0000 |
| ImageNet-64 HF | K8 light | 0.0852 | 0.0305 | 6.758 | 0.0000 |

### Table 2: Order Sensitivity

Use the table in:

```text
../CoFiTok-internal/docs/reports/cofitok_mvp_report_2026-07-08.md
```

### Table 3: Generated-Sample Smoke and HF 50k Protocol

| Dataset | Method | Generated | Real | Low-res Frechet | Inception Frechet |
|---|---|---:|---:|---:|---:|
| Tiny ImageNet-200 | epsilon-only | 8192 | 8192 | 7.5761 | 272.9955 |
| Tiny ImageNet-200 | K8 light | 8192 | 8192 | 7.3264 | 271.0260 |
| ImageNet-64 HF | epsilon-only | 8192 | 8192 | 6.5490 | 240.8919 |
| ImageNet-64 HF | K8 light | 8192 | 8192 | 6.6993 | 269.2785 |
| ImageNet-64 HF | epsilon-only | 50000 | 50000 | 6.4496 | 238.0329 |
| ImageNet-64 HF | K8 light | 50000 | 50000 | 6.6096 | 266.8045 |
| Tiny ImageNet-200 | epsilon-only multiscale | 10000 | 10000 | 5.2057 | 136.7132 |
| Tiny ImageNet-200 | K8 light multiscale | 10000 | 10000 | 5.7001 | 141.4577 |
| ImageNet-64 HF | epsilon-only multiscale | 50000 | 50000 | 5.5593 | 134.2443 |
| ImageNet-64 HF | K8 light multiscale | 50000 | 50000 | 6.2099 | 136.8376 |

### Table 4: Component Separation Pressure

Source:

```text
../CoFiTok-internal/docs/records/2026-07-08_component_decorrelation_tiny_seed_confirmation.md
../CoFiTok-internal/artifacts/reports/component_decorrelation_tiny_conservative_seed_confirm_2026-07-08/component_decorrelation_tiny_conservative_seed_confirm_summary.json
```

| Seed | Variant | Ordered path AUC | Mean abs cosine | Final MSE | Effective K |
|---:|---|---:|---:|---:|---:|
| 139 | baseline | 0.0766 | 0.7223 | 0.1487 | 6.8043 |
| 139 | scheduled decor 0.003 | 0.0804 | 0.6890 | 0.1486 | 6.8316 |
| 103 | baseline | 0.0740 | 0.6967 | 0.1503 | 6.8430 |
| 103 | scheduled decor 0.003 | 0.0776 | 0.6644 | 0.1501 | 6.8829 |

Use this as an ablation table only. The headline CoFiTok objective remains the
no-decorrelation light denoise-path objective.

## Figure-Quality TODOs

- Convert the method SVG and selected PNG panels to final LaTeX figure layout
  after choosing a venue/template.
- Convert selected PNG panels to final LaTeX figure layout after choosing a
  venue/template.
- Keep generated-sample panels labelled as qualitative smoke evidence.
- Add exact sample counts to generated-sample captions.
- Use verified source paths from figure manifests, not hand-copied filenames.
