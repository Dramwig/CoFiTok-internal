# CoFiTok AAAI-27 Submission Build

This directory contains an AAAI-27 anonymous-submission adaptation of the
venue-neutral CoFiTok LaTeX draft.

Official template source:

```text
https://aaai.org/authorkit27/
```

Local template files copied from the official author kit:

```text
aaai2027.sty
aaai2027.bst
ReproducibilityChecklist.tex
```

Build with:

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

or:

```bash
make
```

Current status:

- Uses `\usepackage[submission]{aaai2027}` for anonymous submission.
- Keeps author metadata anonymous with `Anonymous Submission`.
- Uses the official AAAI-27 bibliography style through `aaai2027.sty`.
- Reproducibility checklist is copied locally but not input into `main.tex`
  until the exact submission requirement is finalized.

Before submission, verify the latest AAAI-27 instructions, page limit,
supplement/checklist handling, author metadata, and source-file naming rules.
