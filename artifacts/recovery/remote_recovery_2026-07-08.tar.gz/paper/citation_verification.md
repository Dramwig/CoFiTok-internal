# Citation Verification Log

Date: 2026-07-08

Method:

1. Queried the arXiv API at `https://export.arxiv.org/api/query` using each
   arXiv ID listed below.
2. Retrieved BibTeX from the arXiv BibTeX endpoint
   `https://arxiv.org/bibtex/<arxiv_id>`.
3. Verified DOI resolution through `https://doi.org/10.48550/arXiv.<arxiv_id>`
   with `Accept: application/x-bibtex`.
4. Semantic Scholar was used as an additional check where the API did not rate
   limit. It confirmed DDPM and Selftok in this run; the DOI resolver confirmed
   every arXiv DOI below.

The entries in `references.bib` are based on arXiv BibTeX metadata with stable
local citation keys and LaTeX-safe ASCII author-name escaping where needed.

Claim-level related-work checks are recorded in `citation_claim_audit.md`; the
full-PDF pass is recorded in `full_pdf_claim_audit.md` with PDF provenance in
`full_pdf_claim_audit_sources.json`.

| Draft label | BibTeX key | arXiv ID | arXiv API | arXiv BibTeX | DOI resolver | Semantic Scholar |
|---|---|---:|---|---|---|---|
| DDPM | `ho2020denoising` | 2006.11239 | verified | fetched | verified | verified |
| LDM | `rombach2022latentdiffusion` | 2112.10752 | verified | fetched | verified | rate-limited |
| LatentForcing | `baade2026latentforcing` | 2602.11401 | verified | fetched | verified | rate-limited |
| SpectralTokenizer | `esteves2025spectral` | 2412.09607 | verified | fetched | verified | rate-limited |
| FlexTok | `bachmann2025flextok` | 2502.13967 | verified | fetched | verified | rate-limited |
| MRL | `kusupati2024matryoshka` | 2205.13147 | verified | fetched | verified | rate-limited |
| M3 | `cai2024matryoshkamultimodal` | 2405.17430 | verified | fetched | verified | rate-limited |
| Selftok | `wang2025selftok` | 2505.07538 | verified | fetched | verified | verified |
| DAR | `gao2025dar` | 2505.23660 | verified | fetched | verified | rate-limited |

Remaining citation work before submission:

- Decide whether to replace arXiv `@misc` entries with conference-proceedings
  entries for papers with published venue versions.
- Add any missing related work suggested by human review.
- Re-run the full-PDF audit if the related-work claims are expanded or
  materially rewritten.
