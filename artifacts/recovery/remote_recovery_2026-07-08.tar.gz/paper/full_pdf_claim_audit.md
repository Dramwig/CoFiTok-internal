# Full-PDF Citation Claim Audit

Date: 2026-07-08

Scope: this audit checks the current `draft.md` and `latex/main.tex`
related-work framing against the full arXiv PDF text for the current
`references.bib` entries. It supersedes the earlier abstract-level audit for
claim wording, while leaving venue formatting and proceedings metadata as
submission-time tasks.

PDFs were downloaded from arXiv into a temporary OS cache and converted with
`pdftotext -layout -enc UTF-8`. The project stores only this audit and the
small provenance file `full_pdf_claim_audit_sources.json`, not the downloaded
PDFs.

## Source Coverage

| key | arXiv | audit status |
|---|---|---|
| `ho2020denoising` | [2006.11239](https://arxiv.org/abs/2006.11239) | PDF text checked |
| `rombach2022latentdiffusion` | [2112.10752](https://arxiv.org/abs/2112.10752) | PDF text checked |
| `baade2026latentforcing` | [2602.11401](https://arxiv.org/abs/2602.11401) | PDF text checked |
| `esteves2025spectral` | [2412.09607](https://arxiv.org/abs/2412.09607) | PDF text checked |
| `bachmann2025flextok` | [2502.13967](https://arxiv.org/abs/2502.13967) | PDF text checked |
| `kusupati2024matryoshka` | [2205.13147](https://arxiv.org/abs/2205.13147) | PDF text checked |
| `cai2024matryoshkamultimodal` | [2405.17430](https://arxiv.org/abs/2405.17430) | PDF text checked |
| `wang2025selftok` | [2505.07538](https://arxiv.org/abs/2505.07538) | PDF text checked |
| `gao2025dar` | [2505.23660](https://arxiv.org/abs/2505.23660) | PDF text checked |

## Claim Audit

| claim id | current claim | PDF-level result | action |
|---|---|---|---|
| C1 | DDPMs reverse a Gaussian noising process by predicting noise targets. | Supported. The DDPM PDF discusses the reverse process and epsilon-prediction reverse-process parameterization. | Keep current narrowed wording. Do not reintroduce velocity/flow language without adding a separate citation. |
| C2 | Latent diffusion trains diffusion in a learned autoencoder latent space and decodes through the autoencoder/decoder. | Supported. The LDM PDF frames the method as applying diffusion in the latent space of powerful pretrained autoencoders and describes encoder/decoder reconstruction. | Keep the contrast focused on final latent decoding versus CoFiTok's pixel-space denoising algebra. |
| C3 | Latent Forcing orders a denoising trajectory by jointly processing latents and pixels with separately tuned noise schedules. | Supported. The PDF states that it diffuses both latents and pixels with their own time variables and separately tuned schedules, letting latents act as an intermediate-computation scratchpad. | Keep current wording. Do not claim it tokenizes noise prediction. |
| C4 | Spectral Image Tokenizer and FlexTok are ordered image-tokenizer baselines with useful prefixes/partial reconstructions. | Supported. SIT uses DWT-spectrum tokens with coarse-to-fine partial decoding; FlexTok uses variable-length ordered 1D tokens and nested dropout to reconstruct at different token counts. | Keep the distinction that these tokenize images/representations, not dense diffusion noise predictions. |
| C5 | MRL and M3 provide nested/coarse-to-fine representation or visual-token granularity controls. | Supported. MRL is nested embedding-dimensional representation learning; M3 is nested visual-token granularity for LMMs. | Keep them as representation-budget related work, not diffusion baselines. |
| C6 | Selftok and D-AR are the closest conceptual neighbors because they connect diffusion processes and autoregressive tokens. | Supported, and D-AR is especially close. Selftok uses reverse diffusion to construct discrete AR visual tokens; D-AR explicitly recasts image diffusion as next-token prediction and decodes token positions into pixel-space diffusion denoising steps. | Keep novelty scoped to continuous compressed negative-noise components and restricted token-only `S_k`; no "first coarse-to-fine visual token" claim. |
| C7 | CoFiTok is supported as prefix-controllable denoising at comparable endpoint quality, not as an unconditional generation-quality win. | Supported by internal evidence, not external citations. The related-work PDFs do not justify an unconditional quality superiority claim. | Keep current negative/limited wording. |

## Required Text Edits From This Audit

- The codebase validation count has been updated to `109 passed` after adding
  the goal-completion audit tests.
- Keep Latent Forcing wording at "jointly processing latents and pixels with
  separately tuned noise schedules"; this is PDF-supported.
- Keep D-AR wording strong enough to acknowledge the nearest-neighbor risk:
  D-AR decodes token positions into pixel-space denoising steps and naturally
  follows a coarse-to-fine order.
- Keep CoFiTok novelty narrow: dense noise-prediction factorization with
  continuous negative-noise tokens and restricted, condition-free `S_k`.

## Remaining Submission Tasks

- Use the current AAAI-27 anonymous-submission adaptation in `venues/aaai27/`
  unless a different target venue is chosen.
- Decide whether to keep arXiv `@misc` entries or replace any references with
  verified proceedings metadata.
- Re-run this audit if the related-work section is expanded or if stronger
  generation-quality claims are added.
