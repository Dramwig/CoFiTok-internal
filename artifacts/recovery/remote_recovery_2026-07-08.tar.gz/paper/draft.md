# CoFiTok: Coarse-to-Fine Denoising Tokens for Pixel-Space Diffusion

Status: internal first draft. This draft is intentionally scoped to the current
MVP evidence and should not claim state-of-the-art generation quality.

## Abstract

Pixel-space diffusion models usually predict a full dense noise field with a
single monolithic network output. We introduce CoFiTok, a denoising-token
factorization that represents the dense noise prediction as an ordered sum of
compressed negative-noise components. Each token is expanded by a restricted,
condition-free synthesis operator that only sees the current token, so prefix
sums form valid partial noise predictions and produce controllable partial
denoising results in pixel space. On CIFAR-10, Tiny ImageNet-200, and an
ImageNet-1K 64x64 fallback, a tiny CoFiTok predictor with restricted synthesis
learns ordered components with clean zero-token diagnostics, strong
random/reverse-order sensitivity, and broader token utilization than
endpoint-only epsilon training. At the same 20k-step budget, K8 CoFiTok nearly
matches epsilon-only final clean MSE on Tiny ImageNet-200 and ImageNet-64 HF
while improving prefix path AUC by roughly 28--35x. Current generated-sample
Frechet smoke metrics still favor epsilon-only, so CoFiTok's supported claim is
prefix-controllable denoising at comparable endpoint quality rather than
unconditional generation quality wins.

## 1. Introduction

Diffusion models reverse a noising process by repeatedly predicting a dense
noise field. This dense prediction is effective, but it is also monolithic:
there is no direct way to ask how much of the denoising update has been
explained, whether the update has an interpretable coarse-to-fine order, or how
to stop after a valid partial prediction. In contrast, ordered visual tokenizers
and diffusion-autoregressive methods suggest that generation can benefit from
structured intermediate representations. The key question for this paper is
narrower: can the dense pixel-space noise prediction itself be factorized into
ordered denoising tokens?

CoFiTok answers this question by rewriting the predicted noise field as

```text
epsilon_hat = sum_{k=1}^{K} S_k(z_k),
```

where each `z_k` is a compressed negative-noise token and `S_k` expands only
that token into one dense component. Prefixes are meaningful by construction:

```text
epsilon_hat_1:m = sum_{k=1}^{m} S_k(z_k)
x0_hat_1:m = (x_t - sigma_t * epsilon_hat_1:m) / alpha_t.
```

The central design constraint is that the synthesis operator must not become a
decoder. In the default CoFiTok model, `S_k` is token-only, bias-free, shallow,
local, and condition-free. It does not receive the noised image, timestep,
class label, text prompt, previous tokens, skip features, or a learned constant.
This restriction forces the token itself to carry the sample-specific
negative-noise information and gives the zero-token test a concrete meaning:
`S_k(0)=0` by construction.

Our current evidence supports a scoped MVP claim. CoFiTok learns ordered
denoising components on three common public image settings: CIFAR-10, Tiny
ImageNet-200, and an ImageNet-1K 64x64 fallback. Compared with an endpoint-only
epsilon baseline trained for the same 20k steps, the K8 light denoise-path
objective nearly matches final clean MSE on Tiny ImageNet-200 and ImageNet-64
HF, while dramatically improving prefix/path alignment and effective token
usage. Generated-sample distribution smoke metrics remain stronger for
epsilon-only, which clarifies the present contribution: CoFiTok makes dense
noise prediction prefix-controllable without relying on a final VAE-style
decoder.

Contributions:

1. We formulate dense pixel-space diffusion noise prediction as an ordered sum
   of compressed denoising-token components.
2. We introduce a restricted, condition-free synthesis operator whose token-only
   interface and bias-free construction prevent decoder-style shortcuts and
   make `S_k(0)=0` testable.
3. We train CoFiTok with a denoise-path objective that makes token prefixes
   approximate a partial denoising trajectory rather than only the final clean
   image.
4. We evaluate prefix controllability, component ordering, non-degeneration,
   endpoint quality, and generated-sample smoke metrics across CIFAR-10, Tiny
   ImageNet-200, and ImageNet-64 HF.

## 2. Related Work

This section uses verified arXiv BibTeX keys from `references.bib`. See
`citation_verification.md` for provenance and remaining citation TODOs.

Diffusion models and latent diffusion. Denoising diffusion probabilistic models
learn to reverse a Gaussian noising process by predicting noise targets
\cite{ho2020denoising}. Latent diffusion models move this process into a
learned latent space and decode the final latent through a VAE-style decoder
\cite{rombach2022latentdiffusion}. CoFiTok instead stays in the pixel-space denoising algebra and
factorizes the dense noise prediction itself. The CoFiTok token is not a final
image latent; it is a compressed negative-noise component that directly
contributes to the pixel-space denoising update.

Trajectory ordering and latent-pixel interaction. Latent Forcing studies how
changing the schedule between latent and pixel variables changes the
information revealed by the diffusion trajectory \cite{baade2026latentforcing}. CoFiTok is
inspired by this view of trajectory ordering, but tokenizes the noise
prediction inside the reverse trajectory rather than introducing a separate
latent-pixel trajectory.

Ordered visual tokenizers. Spectral Image Tokenizer, FlexTok, Matryoshka
Representation Learning, M3, and related nested-token approaches organize image
or multimodal representations so that prefixes or subsets can be useful
\cite{esteves2025spectral,bachmann2025flextok,kusupati2024matryoshka,cai2024matryoshkamultimodal}. These methods operate on image
representations or visual-token budgets. CoFiTok operates on dense diffusion
noise prediction. Its prefixes are valid pixel-space denoising updates, not
partial decodes from a general image tokenizer.

Diffusion-autoregressive visual tokens. Selftok and D-AR are the closest
conceptual neighbors because they connect diffusion processes and autoregressive
tokens \cite{wang2025selftok,gao2025dar}. CoFiTok differs in the represented object and in the
anti-degeneration mechanism. CoFiTok tokens are continuous compressed
negative-noise components, and the synthesis operator is deliberately weak and
condition-free. The main claim is not that diffusion steps are visual tokens,
but that dense noise prediction can be decomposed into ordered components whose
prefixes are directly usable in the diffusion denoising formula.

## 3. Method

### 3.1 Forward noising and dense prediction

For a clean image `x_0`, timestep `t`, and Gaussian noise `epsilon`, the forward
process is

```text
x_t = alpha_t x_0 + sigma_t epsilon.
```

A standard epsilon-prediction diffusion model learns
`epsilon_theta(x_t, t, c)`. CoFiTok instead predicts an ordered component sum:

```text
epsilon_hat^(K) = sum_{k=1}^{K} S_k(z_k).
```

The current implementation uses unconditional models for the main MVP evidence.
Class labels may exist in datasets, but the restricted synthesis operator never
receives labels, prompts, timesteps, previous tokens, or image features.
The schematic in `method_overview.png` summarizes this dataflow and marks the
blocked paths into `S_k` that define the default method boundary.

### 3.2 Next denoising tokens

The token predictor `T_k` may be expressive. It sees the noised image, timestep,
and previous tokens:

```text
z_1 = T_1(x_t, t)
z_k = T_k(x_t, z_<k, t),  k > 1.
```

In the tiny MVP model, `T_k` is a small U-Net-like predictor with token heads.
The simultaneous-prediction ablation disables token-to-token feedback so every
token head reads the same hidden state.

### 3.3 Restricted synthesis operator

Each token is expanded independently:

```text
epsilon_k = S_k(z_k).
```

The default `S_k` is a bias-free projection followed by a bias-free local
convolution. It is token-only and condition-free. Because no layer has bias and
there is no learned constant input, zero tokens map to zero components:

```text
S_k(0) = 0.
```

This restriction separates CoFiTok from a learned decoder. A deep `S_k`
ablation is included only to test the degeneration risk: it uses biased
nonlinear convolutions while preserving the token-only interface. This ablation
can improve apparent endpoint metrics but fails the zero-token diagnostic, so it
is not the default method.

### 3.4 Prefix denoising

For any prefix length `m`, CoFiTok forms

```text
epsilon_hat^(1:m) = sum_{k=1}^{m} S_k(z_k)
x0_hat^(m) = (x_t - sigma_t * epsilon_hat^(1:m)) / alpha_t.
```

Thus every prefix is a valid partial noise prediction and every prefix produces
a pixel-space denoising result. This is the primary interface exposed by the
method.

### 3.5 Denoise-path objective

The current MVP objective is

```text
L = L_epsilon
  + 0.15 * L_denoise_path_prefix
  + 0.30 * L_denoise_path_component.
```

The denoise path interpolates from the zero-update `x_t` reconstruction toward
coarse-to-fine spatial targets. The progress schedule uses power 1.5 in the
current best MVP configuration. This objective deliberately avoids forcing early
prefixes to be immediately clean; instead, prefixes are trained to follow a
partial denoising path.

## 4. Experiments

### 4.1 Experimental setup

Datasets. We evaluate on CIFAR-10 as a smoke and diagnostic dataset, Tiny
ImageNet-200 as the main MVP dataset, and an ImageNet-1K 64x64 Hugging Face
fallback as an ImageNet-family validation setting. The preferred TFDS
`downsampled_imagenet/64x64` source was attempted but not available in the
current environment; therefore the fallback is always named explicitly.

Models. All current experiments use tiny models. The main method is K8 light
denoise-path CoFiTok with restricted synthesis. We also evaluate K4 and K16 on
ImageNet-64 HF, epsilon-only endpoint training, channel-mask controls,
simultaneous-predictor ablations, and deep-`S_k` synthesis ablations.

Metrics. We report final clean MSE, prefix denoise-path AUC, effective token
count, zero-token component energy ratio, shuffled-token relative mismatch,
PSNR, LPIPS Alex, low-res Frechet proxy, torchvision Inception Frechet, and
generated-sample smoke-to-50k streamed Frechet. Generated-sample Frechet is
computed up to 8192 generated samples against 8192 real validation images for
the main Tiny/HF rows, up to 50000/50000 for the HF ImageNet-64 fallback, and
with matched 20k multiscale controls on Tiny and HF.
This is still an internal torchvision Inception-Frechet protocol rather than an
external official FID benchmark claim.

Validation. The current validation suite passes on the `pro6000` server.
Summary artifacts contain 111 training reports, 95 order-evaluation reports,
58 fixed-timestep quality reports, 22 sampling reports, and 29
generated-quality reports. A deterministic full-validation reconstruction and
prefix sweep covers the main Tiny ImageNet-200 10k-validation and ImageNet-64
HF 50k-validation rows. The stronger multiscale predictor also has matched
20k train-scale rows and generated-quality controls on Tiny ImageNet-200 and
ImageNet-64 HF while preserving the restricted `S_k` contract.

### 4.2 Does CoFiTok preserve endpoint quality while improving prefixes?

At the same 20k training budget, K8 light CoFiTok nearly matches epsilon-only
final clean MSE while greatly improving path alignment.

| Dataset | Method | Final clean MSE | Path AUC | Effective K | Zero ratio |
|---|---:|---:|---:|---:|---:|
| Tiny ImageNet-200 | epsilon-only | 0.1413 | 1.1121 | 5.336 | 0.0000 |
| Tiny ImageNet-200 | K8 light | 0.1427 | 0.0388 | 6.780 | 0.0000 |
| ImageNet-64 HF | epsilon-only | 0.0842 | 1.0746 | 5.240 | 0.0000 |
| ImageNet-64 HF | K8 light | 0.0852 | 0.0305 | 6.758 | 0.0000 |

The endpoint gap is small: 0.0014 MSE on Tiny ImageNet-200 and 0.0010 MSE on
ImageNet-64 HF. The path-AUC reduction is large: approximately 28.7x on Tiny
ImageNet-200 and 35.2x on ImageNet-64 HF. Figure
`prefix_comparison_20k.png` shows the corresponding qualitative prefix grids.
In the full-validation deterministic sweep, K8 light also improves MSE AUC and
low-res Frechet proxy AUC on both Tiny ImageNet-200 and ImageNet-64 HF, while
epsilon-only keeps the lower endpoint MSE.

### 4.3 Is component order meaningful?

Order ablations keep the same component sum at the endpoint but change the
prefix trajectory. This makes order evaluation a direct test of whether
prefixes are organized rather than an endpoint-quality test.

| K | Order | Final MSE | Path AUC | Zero ratio |
|---:|---|---:|---:|---:|
| 4 | ordered | 0.1029 | 0.0674 | 0.0000 |
| 4 | random | 0.1029 | 0.0727 | 0.0000 |
| 4 | reverse | 0.1029 | 0.7516 | 0.0000 |
| 8 | ordered | 0.1041 | 0.0635 | 0.0000 |
| 8 | random | 0.1041 | 0.2441 | 0.0000 |
| 8 | reverse | 0.1041 | 0.6947 | 0.0000 |
| 16 | ordered | 0.1021 | 0.0680 | 0.0000 |
| 16 | random | 0.1021 | 0.4680 | 0.0000 |
| 16 | reverse | 0.1021 | 0.7020 | 0.0000 |

K8 gives the best current tradeoff: it uses tokens broadly and shows clear
random/reverse degradation. K4 is a strong cost baseline but has less room for a
rich prefix curriculum. K16 does not improve path AUC at 5k steps and likely
requires longer training or stronger shaping before becoming worthwhile. Seed
103 repeats for K4 and K16 preserve the same pattern: reverse order damages
prefix path quality in both cases, while K16 random order is also strongly
worse than ordered accumulation.

### 4.4 Does restricted synthesis avoid decoder degeneration?

The restricted synthesis operator has zero-token component energy ratio 0.0 in
the restricted reports. The deep-`S_k` ablation improves some endpoint/path
numbers but has a nonzero zero-token ratio:

```text
deep S_k final clean MSE: 0.0977
deep S_k path AUC:        0.0366
deep S_k zero ratio:      0.0522
```

This result supports the design boundary. A stronger synthesis operator can
carry token-independent priors and improve apparent metrics, but then it no
longer satisfies the default CoFiTok restriction. A seed-103 repeat shows the
same failure mode with zero-token ratio 0.0450. Figure
`sk_diagnostic_panel.png` visualizes restricted/deep and shuffled-token panels.

### 4.5 Does explicit component separation help?

We treat component decorrelation as a pressure-term ablation rather than a
default objective. The headline CoFiTok rows use the no-decorrelation light
denoise-path objective because it most directly measures ordered prefix
denoising. On Tiny ImageNet-200, a conservative schedule
(`weight=0.003`, start step 3000, warmup 1500, full weight at step 4500 of 5000)
reduces component correlation on two seeds while keeping the ordered-prefix
penalty small.

| Seed | Variant | Ordered path AUC | Mean abs cosine | Final MSE | Effective K |
|---:|---|---:|---:|---:|---:|
| 139 | baseline | 0.0766 | 0.7223 | 0.1487 | 6.8043 |
| 139 | scheduled decor 0.003 | 0.0804 | 0.6890 | 0.1486 | 6.8316 |
| 103 | baseline | 0.0740 | 0.6967 | 0.1503 | 6.8430 |
| 103 | scheduled decor 0.003 | 0.0776 | 0.6644 | 0.1501 | 6.8829 |

Across the two seeds, scheduled decor 0.003 changes ordered path AUC by +0.0036,
mean absolute component cosine by -0.0328, final MSE by -0.0002, and effective
token count by +0.0336. Thus mild separation pressure can make components less
correlated without materially breaking ordered prefix behavior. Stronger decor
weights reduce cosine further but impose larger path-AUC penalties, so we keep
them as stress-test ablations rather than the default CoFiTok objective.

### 4.6 How does CoFiTok compare on fixed-timestep quality?

Fixed-timestep 256-image validation shows that epsilon-only remains a strong
endpoint baseline. K8 light is close on PSNR/LPIPS, but it is not uniformly
better on endpoint metrics.

| Dataset | Method | Steps | Final PSNR | Final Inception | Final LPIPS |
|---|---|---:|---:|---:|---:|
| CIFAR-10 | epsilon-only | 3k | 14.390 | 334.069 | 0.1639 |
| CIFAR-10 | K8 light | 3k | 14.170 | 327.889 | 0.1674 |
| Tiny ImageNet-200 | epsilon-only | 20k | 14.976 | 344.162 | 0.5479 |
| Tiny ImageNet-200 | K8 light | 20k | 14.865 | 346.083 | 0.5505 |
| ImageNet-64 HF | epsilon-only | 20k | 15.743 | 330.643 | 0.5204 |
| ImageNet-64 HF | K8 light | 20k | 15.558 | 360.795 | 0.5150 |

The main value of CoFiTok is endpoint quality together with prefix
controllability and non-degenerate ordered components.

A seed-103 ImageNet-64 HF quality slice gives the same qualitative endpoint
picture at 5k steps. Epsilon-only reaches final MSE 0.1227; K4/K8/K16 light
reach 0.1243/0.1247/0.1298 while improving MSE AUC from 8.0990 to
4.9383/6.7878/7.7460. This slice is still a 256-image fixed-timestep
reconstruction metric, not sample FID.

### 4.7 Does CoFiTok beat epsilon-only on generated-sample quality?

No stable win is established at the current model scale. DDIM generated-sample
smoke metrics are mixed across sample counts and datasets.

| Dataset | Method | Generated | Real | Low-res Frechet | Inception Frechet |
|---|---|---:|---:|---:|---:|
| Tiny ImageNet-200 | epsilon-only | 8192 | 8192 | 7.5761 | 272.9955 |
| Tiny ImageNet-200 | K8 light | 8192 | 8192 | 7.3264 | 271.0260 |
| ImageNet-64 HF | epsilon-only | 8192 | 8192 | 6.5490 | 240.8919 |
| ImageNet-64 HF | K8 light | 8192 | 8192 | 6.6993 | 269.2785 |
| ImageNet-64 HF | epsilon-only | 50000 | 50000 | 6.4496 | 238.0329 |
| ImageNet-64 HF | K8 light | 50000 | 50000 | 6.6096 | 266.8045 |
| Tiny ImageNet-200 | epsilon-only multiscale | 10000 | 10000 | 5.2057 | 136.7132 |
| Tiny ImageNet-200 | K8 light multiscale | 10000 | 10000 | 5.7001 | 141.4577 |
| ImageNet-64 HF | epsilon-only multiscale | 50000 | 50000 | 5.5593 | 134.2443 |
| ImageNet-64 HF | K8 light multiscale | 50000 | 50000 | 6.2099 | 136.8376 |

These results prevent an overclaim. CoFiTok currently demonstrates
prefix-controllable denoising at comparable endpoint quality, not a robust
unconditional sample-quality improvement. Earlier 1024/4096 DDIM-20 slices favor
epsilon-only on both datasets; the 8192/8192 DDIM-50 streamed protocol slightly
favors K8 light on Tiny ImageNet-200 but still favors epsilon-only on
ImageNet-64 HF. The older tiny-conv 50000/50000 HF streamed protocol again
favors epsilon-only, and the matched multiscale 20k controls favor epsilon-only
on both Tiny ImageNet-200 and ImageNet-64 HF generated-sample Frechet.

## 5. Discussion

CoFiTok suggests that dense pixel-space diffusion noise prediction can be
treated as a sequence of ordered denoising-token components. The restricted
synthesis operator is central: it gives the prefix interface meaning and
prevents the method from becoming a generic latent decoder. The denoise-path
objective is also central because early prefixes should represent partial
denoising rather than clean reconstructions.

The strongest empirical result is the combination of near-matched final clean
MSE and large prefix path-AUC gains at 20k steps. The most important negative
result is that generated-sample Frechet smoke metrics do not show a stable
unconditional generation-quality win. Together, these results define the current
scope of the contribution.

## 6. Limitations

The current models are tiny and trained with MVP budgets. Generated-sample
Frechet now reaches 50000 generated vs 50000 real images for the HF fallback,
but remains an internal streamed small-model protocol rather than an external
official FID benchmark, and it does not show a robust CoFiTok sample-quality
win. Fixed-timestep Inception/LPIPS metrics use 256-image validation slices.
Seed repeats cover the main epsilon/K8 comparison but not every ablation. The ImageNet-family
validation uses an HF ImageNet-1K 64x64 fallback because the preferred
`downsampled_imagenet/64x64` source was unavailable in the current environment.
The paper still needs final venue formatting, proceedings-metadata decisions
where relevant, and camera-ready figure captions.

## 7. Conclusion

CoFiTok factorizes pixel-space diffusion noise prediction into an ordered
sequence of compressed denoising tokens. Each token is expanded by a restricted,
condition-free synthesis operator into a dense negative-noise component, and
prefix sums yield valid partial denoising results. Across CIFAR-10, Tiny
ImageNet-200, and ImageNet-64 HF, the current MVP evidence shows that CoFiTok
can learn ordered, non-degenerate prefix-controllable components while
preserving endpoint quality close to an epsilon-only baseline. The next step is
to test whether the same factorization remains useful for larger backbones,
longer training, and official generated-sample FID toolchains.
