# Citation Notes

This file prevents accidental citation hallucination. The first citation pass
has generated `references.bib` from programmatic arXiv BibTeX metadata and DOI
resolver checks. See `citation_verification.md` for provenance,
`citation_claim_audit.md` for the abstract-level check, and
`full_pdf_claim_audit.md` for the current full-PDF claim audit.

## Citation Labels Used in `draft.md`

| Label | Intended work | Current status |
|---|---|---|
| `[DDPM]` | Denoising Diffusion Probabilistic Models, Ho et al. | verified as `ho2020denoising`. |
| `[LDM]` | High-Resolution Image Synthesis with Latent Diffusion Models, Rombach et al. | verified as `rombach2022latentdiffusion`. |
| `[LatentForcing]` | Latent Forcing, arXiv:2602.11401 | verified as `baade2026latentforcing`. |
| `[SpectralTokenizer]` | Spectral Image Tokenizer, arXiv:2412.09607 | verified as `esteves2025spectral`. |
| `[FlexTok]` | FlexTok, arXiv:2502.13967 | verified as `bachmann2025flextok`. |
| `[MRL]` | Matryoshka Representation Learning, arXiv:2205.13147 | verified as `kusupati2024matryoshka`. |
| `[M3]` | Matryoshka Multimodal Models, arXiv:2405.17430 | verified as `cai2024matryoshkamultimodal`. |
| `[Selftok]` | Selftok, arXiv:2505.07538 | verified as `wang2025selftok`. |
| `[DAR]` | D-AR / Diffusion via Autoregressive Models, arXiv:2505.23660 | verified as `gao2025dar`. |

## Citation Policy for This Draft

- Do not create BibTeX entries from memory.
- If a paper cannot be verified, leave an explicit TODO rather than inventing
  author lists, venues, or DOIs.
- Related-work claims should be checked against paper abstracts or PDFs before
  submission. The current full-PDF pass is in `full_pdf_claim_audit.md`.
- `references.bib` currently uses arXiv `@misc` entries. If a target venue
  prefers proceedings metadata, replace entries only after programmatic
  verification.
- Re-run `full_pdf_claim_audit.md` if related-work wording changes materially.

## Related-Work Framing Notes

- Do not claim CoFiTok is the first coarse-to-fine visual token method.
- Distinguish CoFiTok from visual tokenizers by the represented object:
  CoFiTok tokens are compressed negative-noise components.
- Distinguish CoFiTok from Selftok/D-AR by the anti-degeneration mechanism:
  `S_k` is restricted, condition-free, and tested with zero/random/shuffle
  diagnostics.
- Distinguish CoFiTok from latent diffusion by avoiding a final VAE-style
  decoder and keeping denoising updates in pixel-space algebra.
