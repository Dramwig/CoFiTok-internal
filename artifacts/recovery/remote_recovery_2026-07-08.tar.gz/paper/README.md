# CoFiTok Paper Draft Workspace

This directory contains the current paper-facing draft material for:

```text
CoFiTok: Coarse-to-Fine Denoising Tokens for Pixel-Space Diffusion
```

Status: first internal draft, generated from verified local and remote
artifacts on 2026-07-08.

Primary sources:

```text
../CoFiTok-internal/docs/reports/cofitok_mvp_report_2026-07-08.md
../CoFiTok-internal/docs/records/2026-07-08_completion_audit.md
../CoFiTok-internal/artifacts/reports/summary_2026-07-08/experiment_summary.json
../CoFiTok-internal/artifacts/figures/method_overview_2026-07-08/method_overview_manifest.json
../CoFiTok-internal/artifacts/figures/summary_2026-07-08/figure_manifest.json
../CoFiTok-internal/artifacts/figures/visual_panels_2026-07-08/visual_panel_manifest.json
```

Files:

```text
draft.md                 Main paper draft in venue-neutral Markdown.
figures_and_tables.md    Figure/table plan and draft captions.
latex/                   Venue-neutral LaTeX draft that compiles locally.
venues/aaai27/           AAAI-27 anonymous-submission LaTeX adaptation.
citation_notes.md        Related-work citation notes and remaining checks.
citation_verification.md Citation provenance log.
citation_claim_audit.md  Abstract-level related-work claim audit.
full_pdf_claim_audit.md  Full-PDF related-work claim audit.
full_pdf_claim_audit_sources.json
                          Full-PDF audit provenance and checksums.
references.bib           Verified arXiv BibTeX entries for current citations.
```

Do not submit this draft as-is. The `venues/aaai27/` directory contains a first
AAAI-27 anonymous-submission adaptation, but it still needs final captions,
author metadata, checklist/supplement decisions, proceedings-metadata decisions
where relevant, and any additional experiments required by the target venue.
