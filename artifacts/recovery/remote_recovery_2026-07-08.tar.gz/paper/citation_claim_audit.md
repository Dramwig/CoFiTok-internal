# Citation Claim Audit

Date: 2026-07-08

Scope: this is the earlier claim-level audit of the current `draft.md`
related-work section against verified arXiv records and abstracts. It is now
superseded for claim wording by `full_pdf_claim_audit.md`, which checks the
current related-work framing against extracted PDF text.

## Sources Checked

| key | source |
|---|---|
| `ho2020denoising` | https://arxiv.org/abs/2006.11239 |
| `rombach2022latentdiffusion` | https://arxiv.org/abs/2112.10752 |
| `baade2026latentforcing` | https://arxiv.org/abs/2602.11401 |
| `esteves2025spectral` | https://arxiv.org/abs/2412.09607 |
| `bachmann2025flextok` | https://arxiv.org/abs/2502.13967 |
| `kusupati2024matryoshka` | https://arxiv.org/abs/2205.13147 |
| `cai2024matryoshkamultimodal` | https://arxiv.org/abs/2405.17430 |
| `wang2025selftok` | https://arxiv.org/abs/2505.07538 |
| `gao2025dar` | https://arxiv.org/abs/2505.23660 |

## Related-Work Claims

| claim id | draft claim | citations | status | action |
|---|---|---|---|---|
| C1 | DDPM-style diffusion models reverse a noising process by learning a dense noise-prediction target. | `ho2020denoising` | supported with wording narrowed | The draft was changed from "noise or related velocity targets" to "noise targets" because the current citation set does not include a separate v-prediction reference. |
| C2 | Latent diffusion moves diffusion into a learned autoencoder latent space and decodes through the pretrained autoencoder/decoder. | `rombach2022latentdiffusion` | supported | The arXiv abstract explicitly describes training diffusion models in the latent space of pretrained autoencoders. Keep the CoFiTok contrast focused on pixel-space denoising algebra and no final VAE-style decoder. |
| C3 | Latent Forcing studies ordering across latent and pixel variables using separately tuned schedules. | `baade2026latentforcing` | supported with caution | The abstract supports jointly processing latents and pixels with separately tuned schedules and an ordered denoising trajectory. Avoid stronger claims about its internal mechanism until a PDF-level read is done. |
| C4 | Spectral Image Tokenizer, FlexTok, MRL, and M3 organize image or multimodal representations so prefixes/subsets/granularities can be useful. | `esteves2025spectral`, `bachmann2025flextok`, `kusupati2024matryoshka`, `cai2024matryoshkamultimodal` | supported | Keep the distinction that these are image/visual/multimodal representation or tokenizer methods, while CoFiTok factorizes dense diffusion noise prediction. |
| C5 | Selftok and D-AR are close neighbors because they connect diffusion processes and autoregressive tokens. | `wang2025selftok`, `gao2025dar` | supported | D-AR is especially close because it maps tokens to diffusion denoising steps in pixel space. Avoid claiming CoFiTok is "first" or broadly superior. |
| C6 | CoFiTok differs by representing compressed negative-noise components and enforcing a restricted, condition-free `S_k`. | internal method docs plus all related-work contrasts | supported by project method, not by external papers | This is a contribution claim. It should be backed by method section, diagnostics, and ablations rather than by related-work citations. |

## Submission TODOs

- Decide whether `references.bib` should keep arXiv `@misc` entries or use
  venue proceedings metadata for works with verified proceedings versions.
- Add a separate citation if the draft reintroduces velocity-prediction,
  v-parameterization, or flow-matching target language.
- Keep all novelty wording scoped: no "first coarse-to-fine visual token"
  claim, and no unconditional-generation quality win claim at the current MVP
  scale.
