# CoFiTok LaTeX Draft

This directory contains a venue-neutral LaTeX conversion of the current
paper-facing Markdown draft.

Primary source:

```text
../draft.md
../figures_and_tables.md
../references.bib
../../CoFiTok-internal/docs/reports/cofitok_mvp_report_2026-07-08.md
```

Build locally with:

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

or:

```bash
make
```

This is not a venue template. Before submission, copy the content into the
chosen conference template and re-check page limits, checklist requirements,
anonymization, figure placement, and citation metadata.
